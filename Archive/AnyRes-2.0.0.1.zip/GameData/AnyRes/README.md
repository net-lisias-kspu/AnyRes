# AnyRes
A simple KSP mod to change to any resolution.

# Why?
I have gotten really tired of having to go in and edit the settings.cfg file, then restart KSP just so I can use my own custom resolution.  I decided I didn't want to have do deal with this and wrote this simple pugin to maky my life easier.  I hope it can save some time!
